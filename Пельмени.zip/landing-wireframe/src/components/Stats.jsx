export default function Stats() {
  return (
    <section className="stats-section">
      <div className="container stats-grid">
        <div className="stat-card">
          <div className="stat-number">500 000+</div>
          <div className="stat-label">Слеплено вручную</div>
          <p className="stat-text">Ни один не ускакал.</p>
        </div>

        <div className="stat-card">
          <div className="stat-number">18 минут</div>
          <div className="stat-label">От заказа до кастрюли</div>
          <p className="stat-text">Быстрее, чем ты найдёшь сметану.</p>
        </div>

        <div className="stat-card">
          <div className="stat-number">0%</div>
          <div className="stat-label">Сои и непонятного</div>
          <p className="stat-text">Только мясо. Ну и тесто, куда без него.</p>
        </div>

        <div className="stat-card">
          <div className="stat-number">Гарантия</div>
          <div className="stat-label">Или вернём сметану</div>
          <p className="stat-text">Если не вкусно — сам виноват, но мы извинимся.</p>
        </div>
      </div>
    </section>
  );
}