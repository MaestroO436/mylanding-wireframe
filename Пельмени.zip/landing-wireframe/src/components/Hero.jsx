export default function Hero() {
  return (
    <section className="hero-section">
      <div className="container hero-content">
        <h1 className="hero-title">
          Пельмени, от которых плачет даже тёща. От счастья.
        </h1>

        <p className="hero-description">
          Лепим руками, замораживаем быстро, варим — и ты уже на диване с тарелкой.
          Никакой химии, только мясо, тесто и любовь.
        </p>

        <div className="hero-actions">
          <a href="#calculator" className="btn btn-primary">
            Посчитать пельмени
          </a>
          <a href="#services" className="btn btn-outline">
            Посмотреть меню
          </a>
        </div>
      </div>
    </section>
  );
}