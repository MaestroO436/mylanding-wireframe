export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-content">
        <div>© {new Date().getFullYear()} ПЕЛЬМЕНИЩЕ. Все пельмени защищены.</div>
        <div>Лепим руками | @pelmeni_master</div>
      </div>
    </footer>
  );
}