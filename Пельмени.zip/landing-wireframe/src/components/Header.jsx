export default function Header() {
  return (
    <header className="header">
      <div className="container header-container">
        <div className="logo">🥟 ПЕЛЬМЕНИЩЕ</div>

        <nav className="nav-menu">
          <a href="#services">Меню</a>
          <a href="#calculator">Калькулятор</a>
          <a href="#portfolio">Результат</a>
          <a href="#contact">Заказать</a>
        </nav>

        <a href="#calculator" className="btn btn-secondary btn-sm">
          Хочу жрать
        </a>
      </div>
    </header>
  );
}