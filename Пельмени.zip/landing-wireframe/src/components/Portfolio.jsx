export default function Portfolio() {
  return (
    <section id="portfolio" className="portfolio-section">
      <div className="container">
        <div className="section-header">
          <h2>До и после</h2>
          <p>Всё, что нужно знать о наших пельменях</p>
        </div>

        <div className="comparison-mockup">
          <div className="comparison-half before">
            <span className="comparison-badge">ДО</span>
            <p>[ Пустая тарелка и грусть ]</p>
          </div>
          <div className="comparison-divider">⟷</div>
          <div className="comparison-half after">
            <span className="comparison-badge">ПОСЛЕ</span>
            <p>[ Тарелка пельменей и счастье ]</p>
          </div>
        </div>

        <div className="center-action">
          <button className="btn btn-secondary">
            Ещё пельменей →
          </button>
        </div>
      </div>
    </section>
  );
}