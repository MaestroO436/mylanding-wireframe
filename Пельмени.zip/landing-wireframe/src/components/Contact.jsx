export default function Contact() {
  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Заявка принята! Пельмени уже лепятся, мы скоро свяжемся.');
  };

  return (
    <section id="contact" className="contact-section">
      <div className="container contact-container">
        <div className="contact-info">
          <h2>Оставь заявку — и пельмени приедут</h2>
          <p>
            Перезвоним, уточним адрес и привезём. Или просто поддержим
            морально, если ты уже поел.
          </p>
          <ul className="feature-list">
            <li>• Расчёт за 1 минуту</li>
            <li>• Подбор под твой аппетит</li>
            <li>• Честные сроки доставки</li>
          </ul>
        </div>

        <div className="contact-form-card">
          <h3>Форма заказа</h3>
          <p className="form-subtitle">Перезвоним в течение 15 минут</p>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <input type="text" placeholder="Как тебя звать?" required />
            </div>
            <div className="form-group">
              <input type="tel" placeholder="+7 (___) ___-__-__" required />
            </div>
            <div className="form-group">
              <textarea placeholder="Сколько пельменей съешь за раз?.." rows="3"></textarea>
            </div>
            <button type="submit" className="btn btn-primary btn-block">
              Хочу пельмени
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}