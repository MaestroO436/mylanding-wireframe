import { useState } from 'react';

export default function Calculator() {
  const [formData, setFormData] = useState({
    category: 'Бабушкины',
    volume: '1',
    address: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(
      `Пельмени вызваны!\nВид: ${formData.category}\nКилограмм: ${formData.volume}\nКуда: ${formData.address || 'уточним'}\n\nКастрюлю ставь заранее.`
    );
  };

  return (
    <section id="calculator" className="calculator-section">
      <div className="container calc-container">
        <div className="calc-info">
          <h2>Сколько пельменей в тебе поместится?</h2>
          <p>
            Укажи объём — мы посчитаем, сколько тебе нужно и когда
            привезти, чтобы ты не остался голодным.
          </p>
          <ul className="feature-list">
            <li>✔ <b>Быстро:</b> расчёт без звонков и ожидания</li>
            <li>✔ <b>Честно:</b> без скрытой сои</li>
            <li>✔ <b>Вкусно:</b> это не опция, это по умолчанию</li>
          </ul>
        </div>

        <div className="calc-card">
          <h3>Заказ пельменей</h3>
          <form onSubmit={handleSubmit} className="calc-form">
            <div className="form-group">
              <label>Какие пельмени?</label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              >
                <option value="Бабушкины">Бабушкины (классика)</option>
                <option value="Куриные">Куриные (лёгкие)</option>
                <option value="С крабом">С крабом (богато)</option>
              </select>
            </div>

            <div className="form-group">
              <label>Сколько килограмм?</label>
              <input
                type="number"
                min="1"
                value={formData.volume}
                onChange={(e) => setFormData({ ...formData, volume: e.target.value })}
                required
              />
            </div>

            <div className="form-group">
              <label>Куда доставить?</label>
              <input
                type="text"
                placeholder="ул. Пельменная, 10"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              />
            </div>

            <button type="submit" className="btn btn-primary btn-block">
              Заказать пельмени
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}