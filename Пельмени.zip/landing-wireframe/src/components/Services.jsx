export default function Services() {
  return (
    <section id="services" className="services-section">
      <div className="container">
        <div className="section-header">
          <h2>Наше пельменное меню</h2>
          <p>Выбирай по настроению и по голоду</p>
        </div>

        <div className="services-grid">
          <div className="service-card">
            <div className="card-image-placeholder">[ Классические ]</div>
            <div className="card-body">
              <span className="card-tag">Классика</span>
              <h3>Бабушкины</h3>
              <p>Свинина + говядина, тонкое тесто. Как в детстве, только без «подожди, ещё не готово».</p>
              <div className="card-price">от 450 ₽ / кг</div>
            </div>
          </div>

          <div className="service-card">
            <div className="card-image-placeholder">[ Куриные ]</div>
            <div className="card-body">
              <span className="card-tag">Лёгкие</span>
              <h3>Куриные</h3>
              <p>Нежные, диетические, для тех, кто «на ПП, но срыв — это часть пути».</p>
              <div className="card-price">от 390 ₽ / кг</div>
            </div>
          </div>

          <div className="service-card">
            <div className="card-image-placeholder">[ КРАБ ]</div>
            <div className="card-body">
              <span className="card-tag">Жирно</span>
              <h3>С крабом</h3>
              <p>Для тех, кто живёт красиво. Пельмени, которые не стыдно подать гостям.</p>
              <div className="card-price">от 890 ₽ / кг</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}